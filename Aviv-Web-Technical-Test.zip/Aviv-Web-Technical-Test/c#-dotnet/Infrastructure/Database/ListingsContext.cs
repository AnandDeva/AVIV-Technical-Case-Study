using Microsoft.EntityFrameworkCore;
using listingapi.Infrastructure.Database.Models;
using System;

namespace listingapi.Infrastructure.Database
{
    public class ListingsContext : DbContext
    {
        public ListingsContext(DbContextOptions<ListingsContext> options) : base(options)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Listing>().HasKey(t => new { t.Id, t.CreatedDate });
            
        }

        public virtual DbSet<Listing> Listings { get; set; }
        public virtual DbSet<ListingHistory> ListingsHistory { get; set; }
    }
}
