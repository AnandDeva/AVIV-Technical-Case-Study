export interface Listing {
  id: number;
  latest_price_eur: number;
  surface_area_m2: number;
  rooms_count: number;
  bedrooms_count: number;
  name: string;
  postal_address: {
    street_address: string;
    postal_code: string;
    city: string;
    country: string;
  };
  description: string;
  updated_date: string;
  price:{
    created_date:Date,
    price_eur:number
  }
}

export interface PriceHistoryInterface {
  updatedDate: string;
  price: number;
}
