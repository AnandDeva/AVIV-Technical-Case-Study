export { default } from './PricesHistory';
