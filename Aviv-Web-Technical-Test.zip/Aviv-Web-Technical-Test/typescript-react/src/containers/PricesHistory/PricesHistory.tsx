import { useEffect, useState } from "react";
import PricesHistoryCard from "@components/PriceHistoryCard";
import styles from "./prices-history.module.scss";
import { PriceHistoryInterface } from "@/interfaces";

const PricesHistory = () => {
  const [priceHistory, setPriceHistory] = useState<PriceHistoryInterface[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const id = window.location.pathname.split("/")[1];

  useEffect(() => {
    fetch(`https://localhost:44398/api/listings/${id}/prices`)
      .then((response) => response.json())
      .then((data) => {
        setPriceHistory(data);
        setIsLoading(false);
      });
  }, [id]);

  return (
    <div className={styles["container"]}>
      <h1>Prices History</h1>
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        priceHistory.map((price, key) => (
          <PricesHistoryCard key={key} priceHistory={price} />
        ))
      )}

      <a href="/" className={styles["link"]}>
        &larr; Back Home
      </a>
    </div>
  );
};

export default PricesHistory;
