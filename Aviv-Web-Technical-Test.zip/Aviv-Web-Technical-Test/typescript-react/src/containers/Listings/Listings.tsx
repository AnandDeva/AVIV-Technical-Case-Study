import { useEffect, useState } from "react";
import ListingCard from "@components/ListingCard";
import ListingForm from "@components/ListingForm";
import { Listing } from "@/interfaces";

import styles from "./listings.module.scss";

const Listings = () => {
  const [listings, setListings] = useState<Listing[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch("https://localhost:44398/api/listings")
      .then((response) => response.json())
      .then((data) => {
        setListings(data);
        setIsLoading(false);
      });
  }, []);

  return (
    <main className={styles["listings"]}>
      <h1 className={styles["listings__title"]}>Main Listings page</h1>
      <div className={styles["listings__wrapper"]}>
        <aside className={styles["listings__aside"]}>
          <h2 className={styles["listings__sub-title"]}>Add a listing</h2>
          <ListingForm />
        </aside>
        <section className={styles["listings__section"]}>
          <h2 className={styles["listings__sub-title"]}>Listings</h2>
          {isLoading ? (
            <p>Loading...</p>
          ) : (
            listings.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))
          )}
        </section>
      </div>
    </main>
  );
};

export default Listings;
