import styles from "./price-history-card.module.scss";
import { PriceHistoryInterface } from "@/interfaces";

interface PriceHistoryCardProps {
  priceHistory: PriceHistoryInterface;
}

const PriceHistoryCard = ({ priceHistory }: PriceHistoryCardProps) => {
  return (
    <div className={styles["container"]}>
      <table className={styles["price-card"]}>
        <tbody>
          <tr className={styles["price-card__header"]}>
            <th scope="col">Date</th>
            <th scope="col">Price (eur)</th>
          </tr>
          <tr>
            <td>{priceHistory.updatedDate}</td>
            <td>{priceHistory.price} EUR</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};
export default PriceHistoryCard;
