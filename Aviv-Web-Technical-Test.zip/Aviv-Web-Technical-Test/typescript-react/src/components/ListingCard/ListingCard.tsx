import styles from "./listing-card.module.scss";
import { Listing } from "../../interfaces";

interface ListingCardProps {
  listing: Listing;
}

const ListingCard = ({ listing }: ListingCardProps) => {
  const {
    latest_price_eur,
    surface_area_m2,
    rooms_count,
    bedrooms_count,
    name,
    postal_address,
    description,
    updated_date,
    price
  } = listing;

  return (
    <article className={styles["listing-card"]}>
      <span className={styles["listing-card__price"]}>
        {price.price_eur.toLocaleString("en-US", {
          style: "currency",
          currency: "EUR",
        })}
      </span>
      <ul className={styles["listing-card__properties"]}>
        <li className={styles["listing-card__properties-item"]}>{name}</li>
        <li className={styles["listing-card__properties-item"]}>
          {surface_area_m2}m<sup>2</sup>
        </li>
        <li className={styles["listing-card__properties-item"]}>
          {rooms_count} rooms, {bedrooms_count} bedrooms
        </li>
      </ul>
      <section className={styles["listing-card__address"]}>
        <address>
          {postal_address.street_address}, {postal_address.postal_code}{" "}
          {postal_address.city}, {postal_address.country}
        </address>
      </section>
      <section className={styles["listing-card__description"]}>
        <h3>Property description: </h3>
        <p>{description}</p>
      </section>
      <div className={styles["listing-card__footer"]}>
        <p className={styles["listing-card__reference"]}>
          Ref: {listing.id} <br />
          Last update: {updated_date}
        </p>
        <a
          href={`/${listing.id}/prices`}
          className={styles["listing-card__link"]}
        >
          See history &rarr;
        </a>
      </div>
    </article>
  );
};

export default ListingCard;
