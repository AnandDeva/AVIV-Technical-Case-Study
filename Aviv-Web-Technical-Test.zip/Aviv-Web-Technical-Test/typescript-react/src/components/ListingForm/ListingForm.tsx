import { useState } from "react";
import styles from "./listing-form.module.scss";

const ListingForm = () => {
  const [listing, setListing] = useState({
    name: "",
    description: "",
    surface_area_m2: 0,
    bedrooms_count: 0,
    rooms_count: 0,
    building_type: "",
    latest_price_eur: 0,
    contact_phone_number: "",
    postal_address: {
      street_address: "",
      city: "",
      postal_code: "",
      country: "",
    },
  });

  const handleChange = (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value } = event.target;
    setListing((prevListing) => ({
      ...prevListing,
      [name]: value,
    }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    fetch("https://localhost:44398/api/listings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(listing),
    });
    setListing({
      name: "",
      description: "",
      surface_area_m2: 0,
      bedrooms_count: 0,
      rooms_count: 0,
      building_type: "",
      latest_price_eur: 0,
      contact_phone_number: "",
      postal_address: {
        street_address: "",
        city: "",
        postal_code: "",
        country: "",
      },
    });
  };

  return (
    <form className={styles["listing-form"]} onSubmit={handleSubmit}>
      <div className={styles["listing-form__card"]}>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            name="name"
            value={listing.name}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="description">Description:</label>
          <textarea
            name="description"
            value={listing.description}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="surface_area_m2">Surface Area (m²):</label>
          <input
            type="number"
            name="surface_area_m2"
            value={listing.surface_area_m2}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="bedrooms_count">Bedrooms Count:</label>
          <input
            type="number"
            name="bedrooms_count"
            value={listing.bedrooms_count}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="rooms_count">Rooms Count:</label>
          <input
            type="number"
            name="rooms_count"
            value={listing.rooms_count}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="building_type">Building Type:</label>
          <select
            name="building_type"
            value={listing.building_type}
            onChange={handleChange}
            className={styles["listing-form__select"]}
          >
            <option value="STUDIO">Studio</option>
            <option value="APARTMENT">Apartment</option>
            <option value="HOUSE">House</option>
          </select>
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="latest_price_eur">Latest Price (EUR):</label>
          <input
            type="number"
            name="latest_price_eur"
            value={listing.latest_price_eur}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="contact_phone_number">Contact Phone Number:</label>
          <input
            type="text"
            name="contact_phone_number"
            value={listing.contact_phone_number}
            onChange={handleChange}
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="street_address">Street Address:</label>
          <input
            type="text"
            name="street_address"
            value={listing.postal_address.street_address}
            onChange={(event) =>
              setListing((prevListing) => ({
                ...prevListing,
                postal_address: {
                  ...prevListing.postal_address,
                  street_address: event.target.value,
                },
              }))
            }
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="city">City:</label>
          <input
            type="text"
            name="city"
            value={listing.postal_address.city}
            onChange={(event) =>
              setListing((prevListing) => ({
                ...prevListing,
                postal_address: {
                  ...prevListing.postal_address,
                  city: event.target.value,
                },
              }))
            }
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="postal_code">Postal Code:</label>
          <input
            type="text"
            name="postal_code"
            value={listing.postal_address.postal_code}
            onChange={(event) =>
              setListing((prevListing) => ({
                ...prevListing,
                postal_address: {
                  ...prevListing.postal_address,
                  postal_code: event.target.value,
                },
              }))
            }
            className={styles["listing-form__input-text"]}
          />
        </div>
        <div className={styles["listing-form__input-group"]}>
          <label htmlFor="country">Country:</label>
          <input
            type="text"
            name="country"
            value={listing.postal_address.country}
            onChange={(event) =>
              setListing((prevListing) => ({
                ...prevListing,
                postal_address: {
                  ...prevListing.postal_address,
                  country: event.target.value,
                },
              }))
            }
            className={styles["listing-form__input-text"]}
          />
        </div>
        <button
          type="submit"
          className={styles["listing-form__button--submit"]}
        >
          Create
        </button>
      </div>
    </form>
  );
};

export default ListingForm;
