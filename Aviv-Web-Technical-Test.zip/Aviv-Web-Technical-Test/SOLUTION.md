# AVIV technical test solution

You can use this file to write down your assumptions and list the missing features or technical revamp that should
be achieved with your implementation.

## Notes

Write here notes about your implementation choices and assumptions.

## Questions

This section contains additional questions your expected to answer before the debrief interview.

- **What is missing with your implementation to go to production?**

	1. Authentication and Authorization.
	2. Proper UI Design. 
	3. Have a deployment and rollback plan.
	4. Alerting On Potential Issues. 

- **How would you deploy your implementation?**

	1. Add a Dockerfile to the Web API project -> Since docker file is already in place, this step can be omitted. 
	2. Change the connection string to the database
	3. Build the Docker image for the Web API application
	4. Create a Docker Compose file to start the Web API application container and the Postgres Server container
	5. Start the containers

- **If you had to implement the same application from scratch, what would you do differently?**

	1. Wire framing the application.
	2. Plan web apps flow.
	3. Validation needs to be considered. 
	4. Back end API development.
	5. Front end UI development. 
	6. Review with the team.
	7. Demo with the stakeholders. 
	8. Clearing out the fixes/enhancements
	9. Deploy the application in UAT/Staging/Production.

- **The application aims at storing hundreds of thousands listings and millions of prices, and be accessed by millions
  of users every month. What should be anticipated and done to handle it?**

	1. Refactoring the code. 
	2. DB schema must be split in to different servers. 
	3. Mirroring the servers based on geographic locations. It will improve robustness even if single Data Center fails
	4. With millions of users, there will be inevitable cheaters. So Making sure the security of the app is in place and monitoring for attacks. In particular, make sure your user database is encrypted and the passwords are encrypted and “salted”
	5. Disaster recovery plan in place. 

  NB : You can update the [given architecture schema](./schemas/Aviv_Technical_Test_Architecture.drawio) by importing it
  on [diagrams.net](https://app.diagrams.net/) 
