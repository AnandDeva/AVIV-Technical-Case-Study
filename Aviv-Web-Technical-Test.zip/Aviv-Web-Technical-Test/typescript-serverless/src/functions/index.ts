export { getListings } from "./listing";
