from listingapi.domain.ports.listing_repository import ListingRepository
