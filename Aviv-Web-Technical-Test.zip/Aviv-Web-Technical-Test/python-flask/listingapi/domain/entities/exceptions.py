class ListingNotFound(Exception):
    pass
