from listingapi.adapters.sql_alchemy_listing_repository.sql_alchemy_listing_repository import (
    SqlAlchemyListingRepository,
)
